package com.adobe.prj.util;

import java.lang.reflect.Method;

import com.adobe.prj.annotation.Column;
import com.adobe.prj.annotation.Table;

public class SQLUtil {
	public static String getCreateSQL(Class<?> clazz) {
		StringBuilder builder = new StringBuilder();
		Table t = clazz.getAnnotation(Table.class);
		if(t != null) {
			builder.append("create table ");
			builder.append(t.name()); // create table products
			builder.append("(");
			Method[] methods = clazz.getMethods();
			for(Method m : methods) {
				if(m.getName().startsWith("get")) {
					Column col = m.getAnnotation(Column.class);
					if( col != null) {
						try {
							builder.append(col.name()); // create table products( PRD_ID 
							builder.append(" ");
							builder.append(col.type()); // create table products( PRD_ID INTEGER
							builder.append(","); // // create table products( PRD_ID INTEGER , PRD_NAME VARCHAR(255)
						} catch(Exception ex) {
							ex.printStackTrace();
						}
					}
				}
			}
		}
		builder.setCharAt(builder.lastIndexOf(","), ')');
		return builder.toString();
	}
}
