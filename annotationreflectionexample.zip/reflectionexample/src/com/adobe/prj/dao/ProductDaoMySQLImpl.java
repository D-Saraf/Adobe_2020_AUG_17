package com.adobe.prj.dao;

import com.adobe.prj.entity.Product;

public class ProductDaoMySQLImpl implements ProductDao {

	@Override
	public void addProduct(Product p) {
		System.out.println("MySQL Store!!!");
	}

}
