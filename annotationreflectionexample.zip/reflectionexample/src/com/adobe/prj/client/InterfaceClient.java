package com.adobe.prj.client;

import com.adobe.prj.dao.ProductDao;
import com.adobe.prj.dao.ProductDaoFactory;
import com.adobe.prj.entity.Product;

public class InterfaceClient {

	public static void main(String[] args) {
//		ProductDao productDao = new ProductDaoMySQLImpl();
		ProductDao productDao = ProductDaoFactory.getProductDao();
		Product p = new Product();
		productDao.addProduct(p);
	}

}
