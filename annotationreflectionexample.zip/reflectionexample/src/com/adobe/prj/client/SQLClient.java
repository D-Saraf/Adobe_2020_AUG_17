package com.adobe.prj.client;

import com.adobe.prj.entity.Mobile;
import com.adobe.prj.entity.Product;
import com.adobe.prj.util.SQLUtil;

public class SQLClient {

	public static void main(String[] args) {
		String sql = SQLUtil.getCreateSQL(Product.class);
		System.out.println(sql);
		
		sql = SQLUtil.getCreateSQL(Mobile.class);
		System.out.println(sql);
	}

}
