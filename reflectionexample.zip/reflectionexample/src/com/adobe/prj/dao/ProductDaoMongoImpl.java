package com.adobe.prj.dao;

import com.adobe.prj.entity.Product;

public class ProductDaoMongoImpl implements ProductDao {

	@Override
	public void addProduct(Product p) {
		System.out.println("MongoDB Store!!!");
	}

}
