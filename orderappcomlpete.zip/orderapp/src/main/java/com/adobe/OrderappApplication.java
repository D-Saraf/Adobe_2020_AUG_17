package com.adobe;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.adobe.prj.entity.Product;
import com.adobe.prj.service.OrderService;

@SpringBootApplication
public class OrderappApplication implements CommandLineRunner {
	
	@Autowired
	private OrderService service;
	
	public static void main(String[] args) {
		   SpringApplication.run(OrderappApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
//		Product[] products = new Product[3];
//		products[0] = new Product(0, "iPhone XR", 54000.00, 100);
//		products[1] = new Product(0, "Sony Bravia", 134000.00, 100);
//		products[2] = new Product(0, "Logitech Mouse", 500.00, 100);
//		
//		for(Product p : products) {
//			service.addProduct(p);
//		}
		
//		Product p = service.getProduct(1);
//		System.out.println(p.getName() + "," + p.getPrice());
		
//		List<Product> prds = service.getByPrice(100000);
//		for(Product p : prds) {
//			System.out.println(p.getName() + "," + p.getPrice());
//		}
		
//		service.updateProduct(3, 300);
	}

}
