package com.adobe.dao;

public interface EmployeeDao {
	void addEmployee();
}
