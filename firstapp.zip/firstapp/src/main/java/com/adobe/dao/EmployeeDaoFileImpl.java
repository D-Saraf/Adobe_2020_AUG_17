package com.adobe.dao;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDaoFileImpl implements EmployeeDao {

	@Override
	public void addEmployee() {
		System.out.println("file Store!!!");
	}

}
