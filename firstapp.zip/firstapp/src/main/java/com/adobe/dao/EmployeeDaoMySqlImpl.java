package com.adobe.dao;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

@Repository
//@Primary
public class EmployeeDaoMySqlImpl implements EmployeeDao {

	@Override
	public void addEmployee() {
		System.out.println("MySQL Store!!!");
	}

}
