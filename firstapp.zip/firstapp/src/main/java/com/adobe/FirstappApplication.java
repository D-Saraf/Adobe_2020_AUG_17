package com.adobe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.adobe.service.SampleService;

@SpringBootApplication
public class FirstappApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(FirstappApplication.class, args);
		
		SampleService service = ctx.getBean("sampleService",SampleService.class);
		service.insertEmployee();
	}

}
