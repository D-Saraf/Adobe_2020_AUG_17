package com.adobe.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.adobe.dao.EmployeeDao;

@Service
public class SampleService {
	
	@Autowired
	@Qualifier("employeeDaoFileImpl")
	private EmployeeDao empDao;
	
	public void insertEmployee() {
		empDao.addEmployee();
	}
	
	
}
